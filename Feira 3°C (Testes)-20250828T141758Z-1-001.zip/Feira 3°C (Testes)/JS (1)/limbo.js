let ballPosition = 1;
let isShuffling = false;

function shuffleCups() {
  if (isShuffling) return;
  isShuffling = true;
  document.getElementById("result").textContent = "Embaralhando...";

  // Esconde a bolinha
  document.getElementById("ball").style.display = "none";

  const cups = [
    document.getElementById("cup1"),
    document.getElementById("cup2"),
    document.getElementById("cup3")
  ];

  let positions = [0, 150, 300]; // posições em px
  let steps = 6;
  let count = 0;

  const shuffleInterval = setInterval(() => {
    // Escolhe dois copos aleatórios para trocar
    let i = Math.floor(Math.random() * 3);
    let j;
    do {
      j = Math.floor(Math.random() * 3);
    } while (j === i);

    // Troca as posições
    [positions[i], positions[j]] = [positions[j], positions[i]];

    // Aplica visualmente
    cups.forEach((cup, index) => {
      cup.style.left = positions[index] + "px";
    });

    count++;
    if (count >= steps) {
      clearInterval(shuffleInterval);
      isShuffling = false;
      document.getElementById("result").textContent = "Escolha um copo!";
    }
  }, 600);
}

// Clique nos copos
document.querySelectorAll(".cup").forEach((cup, index) => {
  cup.addEventListener("click", () => {
    if (isShuffling) return;

    const clickedCup = index + 1;

    if (clickedCup === ballPosition) {
      cup.appendChild(document.getElementById("ball"));
      document.getElementById("ball").style.display = "block";
      document.getElementById("result").textContent = "🎉 Você acertou!";
    } else {
      const correctCup = document.getElementById(`cup${ballPosition}`);
      correctCup.appendChild(document.getElementById("ball"));
      document.getElementById("ball").style.display = "block";
      document.getElementById("result").textContent = `😢 Errou! A bolinha estava no copo ${ballPosition}`;
    }
  });
});
